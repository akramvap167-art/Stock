# Personal Inventory Management - Flutter Android App

100% Offline SQLite personal inventory management app with profit calculation and transaction history.

## How to Build the APK

### Method 1: Using Flutter on your computer (Fastest)
1. Install Flutter (https://flutter.dev)
2. Run in this directory:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
3. Your installer APK will be ready at:
   `build/app/outputs/flutter-apk/app-release.apk`
4. Install on your Android phone:
   ```bash
   adb install build/app/outputs/flutter-apk/app-release.apk
   ```
   Or transfer the `app-release.apk` file to your phone via USB, WhatsApp, Telegram, or Google Drive and tap to install!

### Method 2: Free 1-Click Cloud APK Build via GitHub Actions
1. Push this project to a free GitHub repository.
2. Go to the **Actions** tab on your GitHub repo.
3. Click **Build Android APK** -> **Run workflow**.
4. In ~2 minutes, download the ready-to-install **app-release.apk** from the build artifacts!
